import React from 'react';
import { Link } from 'react-router-dom'

function Navigation(){
    return(
    <nav>
        <p>
        <Link to="/">HomePage</Link>
        </p>
        <p>
        <Link to="/add-exercise">Add</Link>
        </p>
    </nav>
)}

export default Navigation