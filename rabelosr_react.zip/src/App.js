import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AddExercisePage from './pages/AddExercisePage';
import EditExercisePage from './pages/EditExercisePage';
import { useState } from 'react'
import Navigation from "./components/Navigation"

function App() {
  const [exerciseToEdit, setExerciseToEdit] = useState();

  return (
    <div className="App">
      <Router>
        <div className="App-header">
          <header>
          <h1>
            The Exercise App
          </h1>
          <p>
            Enter and edit your workouts here
          </p>
          </header>
          <Navigation> </Navigation>
          <Route path="/" exact>
          <HomePage setExerciseToEdit={setExerciseToEdit} />
          </Route>
          <Route path="/add-exercise">
            <AddExercisePage />
          </Route>
          <Route path="/edit-exercise">
            <EditExercisePage exerciseToEdit={exerciseToEdit}/>
          </Route>
          </div>
          <footer>
            © 2022 Riley Rabelos
          </footer>
      </Router>
    </div>
  );
}

export default App;